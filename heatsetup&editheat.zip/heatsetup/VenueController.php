<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class SocialController extends Controller
{
     public function heatSetup(Request $request){
  if($request->session()->has('user_id')){
      $event_id = $request->id;
      return view('heatsetup',['event_id'=>$event_id]);
  }
  else{
      $request->session()->flash('message.level','danger');
      $request->session()->flash('message.content','please login to continue...');
      return view('login');
  }
 }
 public function saveheatSetup(Request $request){
  $user_id = $request->session()->get('user_id');
  $event_id = $request->id;
  $stage_no = $request->stage_no;
  $heat_generation = $request->heat_generation;
  $heat_name = $request->heat_name;
  $schedule_time = $request->schedule_time;
  $qualification = $request->qualification;
  $schedule_date = $request->schedule_date;
  $max_participants = $request->max_participants;
  $relay = $request->relay;
  $course = $request->course;
  $swim_style = $request->swim_style;
  $specialinstructions = $request->specialinstructions;
  $description = $request->descriptions;

  $add_heat = DB::table('eventheats')->insertGetId(array('EventId'=>$event_id,'HeatName'=>$heat_name,'HeatStartDate'=>$schedule_date,'HeatTime'=>$schedule_time,'StageNumber'=>$stage_no,'MaxNOOfParticipants'=>$max_participants,'VenueId'=>$user_id,'QualificationTime'=>$qualification,'Relay'=>$relay,'SwimCourse'=>$course,'SwimStyle'=>$swim_style,'ChildHeatId'=>0,'VenueHeatSpecialInstructions'=>$specialinstructions,'HeatNotes'=>$description,'CreatedBy'=>$user_id,'UpdatedBy'=>$user_id));
  if($add_heat){
    $request->session()->flash('message.level','success');
      $request->session()->flash('message.content','Heat added Successfully <a href="'.url('manageparticipants/'.$event_id.'/'.$add_heat).'"> Click here</a>  to Add participants to Heat.');
      return view('heatsetup',['stage_no'=>$stage_no,'event_id'=>$event_id]);
  }
  else{
    $request->session()->flash('message.level','danger');
      $request->session()->flash('message.content','Heat not added.Please try again..');
      return view('heatsetup',['stage_no'=>$stage_no,'event_id'=>$event_id]);
  }
 }
 public function manageParticpants(Request $request){
  if($request->session()->has('user_id')){
      $user_id = $request->session()->get('user_id');
      $event_id = $request->event_id;
      $heat_id = $request->heat_id;
      $participants = DB::select('SELECT DISTINCT participants.ParticipantId,participants.ParticipantName FROM participants INNER JOIN bridgeeventparticipants where participants.ParticipantId = bridgeeventparticipants.ParticipantId and bridgeeventparticipants.EventId=? and bridgeeventparticipants.Status=?',[$event_id,0]);
      $mainheat = DB::select('select HeatName from eventheats where HeatId=? and EventId=?',[$heat_id,$event_id]);
      $heatname = $mainheat[0]->HeatName;
      $heats = DB::select('select HeatId,HeatName from eventheats where EventId=?',[$event_id]);
      $heat_participants = DB::select('select DISTINCT p.ParticipantId,p.ParticipantName from participants p INNER JOIN bridgeheatparticipants b where p.ParticipantId=b.ParticipantId and b.EventId=? and b.HeatId=?',[$event_id,$heat_id]);
      return view('manageparticipants',['participants'=>$participants,'heatname'=>$heatname,'heats'=>$heats,'event_id'=>$event_id,'heat_id'=>$heat_id,'heat_participants'=>$heat_participants]);
    }
    else{
      $request->session()->flash('message.level','danger');
      $request->session()->flash('message.content','Passwords didnot match. Please,Try again..');
      return redirect('login');
    }
 }
 public function saveParticipants(Request $request){
    $user_id = $request->session()->get('user_id');
    $participant = $request->participants;
    $heats_participants = $request->heats_participants;
    $heats_id = $request->heats_id;
    $heat_id = $request->heat_id;
    $event_id = $request->event_id;
    $subevent_id = $request->subevent_id;
    if($participant!=''){
      for($i=0;$i<count($participant);$i++){
        $eventparticipants = DB::update('update bridgeeventparticipants set Status=? where EventId=? and ParticipantId=?',[1,$event_id,$participant[$i]]);
        $set_heatparticipants = DB::table('bridgeheatparticipants')->insertGetId(array('HeatId'=>$heat_id,'EventId'=>$event_id,'ParticipantId'=>$participant[$i],'CreatedBy'=>$user_id,'StageNo'=>0,'AssignStatus'=>0));
      }
      $request->session()->flash('message.level','success');
    $request->session()->flash('message.content','Participants Moved to heat');
    return redirect('manageparticipants/'.$event_id.'/'.$heat_id);
    }
    elseif($heats_participants!=''){
      for($i=0;$i<count($heats_participants);$i++){
        $heatparticipants = DB::delete('delete from bridgeheatparticipants where ParticipantId=? and EventId=? and HeatId=?',[$heats_participants[$i],$event_id,$heat_id]);
        $set_eventparticipants = DB::update('update bridgeeventparticipants set Status=? where EventId=? and ParticipantId=?',[0,$event_id,$heats_participants[$i]]);;
      }
        $request->session()->flash('message.level','success');
    $request->session()->flash('message.content','Participants Removed from heat');
    return redirect('manageparticipants/'.$event_id.'/'.$heat_id);
    }
    else{
      $request->session()->flash('message.level','success');
      $request->session()->flash('message.content','Changes saved Sucessfully');
    return redirect('manageparticipants/'.$event_id.'/'.$heat_id);
    }
  }
  public function oldHeatSchedule(Request $request){
    $event_id = $request->event_id;
    $heat_id = $request->heat_id;
    $schedules = DB::select('select HeatId,HeatName,HeatStartDate,HeatTime,QualificationTime from eventheats where EventId=?',[$event_id]);
    echo '<h5 class="add_venue"><a href="#"><button class="btn btn-primary" style="background-color:#fff;color:#46A6EA"><i class="fa fa-plus"></i></button></a> Previous Entries</h5>';
                echo '<div class="row" style="border:1px solid #eee">';
                echo "<table class='table table-striped'>";
                echo "<tr><th>Heat Name</th><th>Heat StartDate</th><th>HeatTime</th><th>QualificationTime</th><th>Edit</th><th>Delete</th></tr>";
                foreach($schedules as $schedule) {
                    echo "<tr><td>".$schedule->HeatName."</td><td>".$schedule->HeatStartDate."</td><td>".$schedule->HeatTime."</td><td>".$schedule->QualificationTime."</td><td><a href=".url('/editheat/'.$event_id.'/'.$schedule->HeatId)." style='color:black;'>Edit</a></td><td>Delete</td></tr>";
                }
                echo "</table>";
                echo '</div>';
  }
  public function editheat(Request $request){
    if($request->session()->get('user_id')){
      $event_id = $request->event_id;
      $heat_id = $request->heat_id;
      $heat_details = DB::select('select * from eventheats where HeatId=? and EventId=?',[$heat_id,$event_id]);
      return view('editheat',['event_id'=>$event_id,'heat_id'=>$heat_id,'heat_details'=>$heat_details]);
    }
    else{
      $request->session()->flash('message.level','danger');
      $request->session()->flash('message.content','Passwords didnot match. Please,Try again..');
      return redirect('login');
    }
  }
  public function saveeditheat(Request $request){
    $user_id = $request->session()->get('user_id');
  $event_id = $request->event_id;
  $heat_id = $request->heat_id;
  $stage_no = $request->stage_no;
  $heat_generation = $request->heat_generation;
  $heat_name = $request->heat_name;
  $schedule_time = $request->schedule_time;
  $qualification = $request->qualification;
  $schedule_date = $request->schedule_date;
  $max_participants = $request->max_participants;
  $relay = $request->relay;
  $course = $request->course;
  $swim_style = $request->swim_style;
  $specialinstructions = $request->specialinstructions;
  $description = $request->descriptions;
  $update_heat = DB::update('update eventheats set HeatName=?,HeatStartDate=?,HeatTime=?,StageNumber=?,MaxNoOfParticipants=?,QualificationTime=?,Relay=?,SwimCourse=?,SwimStyle=?,VenueHeatSpecialInstructions=?,HeatNotes=? where HeatId=?',[$heat_name,$schedule_date,$schedule_time,$stage_no,$max_participants,$qualification,$relay,$course,$swim_style,$specialinstructions,$description,$heat_id]);
  if($update_heat){
    $request->session()->flash('message.level','success');
      $request->session()->flash('message.content','Heat Details updated Sucessfully');
      return redirect('editheat/'.$event_id.'/'.$heat_id);
  }
  else{
    $request->session()->flash('message.level','danger');
      $request->session()->flash('message.content','No Changes made to heats.Please try again...');
      return redirect('editheat/'.$event_id.'/'.$heat_id);
  }
  }
}
