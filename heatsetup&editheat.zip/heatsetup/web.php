<?php

Route::get('/heatsetup/{id}','VenueController@heatSetup');
Route::post('/heatsetup/{id}','VenueController@saveheatSetup');
Route::get('/editheat/{event_id}/{heat_id}','VenueController@editheat');
Route::post('/editheat/{event_id}/{heat_id}','VenueController@saveeditheat');
Route::get('/oldscheduleheat/{event_id}','VenueController@oldHeatSchedule');
Route::get('/manageparticipants/{event_id}/{heat_id}','VenueController@manageParticpants');
Route::post('/manageparticipants/{event_id}/{heat_id}','VenueController@saveParticipants');
