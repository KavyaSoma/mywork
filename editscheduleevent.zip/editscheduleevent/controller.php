<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use DB;
use session;


class EventController extends Controller
{
   public function editEventContact(Request $request){
        if($request->session()->has('user_id')){
            $event_id = $request->id;
            $start_date = $request->start_date;
            $end_date = $request->end_date;
            $user_id = $request->session()->get('user_id');
            $contacts = DB::select('select b.ContactId,c.ContactId,c.FirstName,c.Phone,c.Email from bridgeeventcontact b INNER JOIN contacts c where EventId=? and CreatedBy=? and b.ContactId=c.ContactId',[$event_id,$user_id]);
            $clubs = DB::select('select c.ClubId,c.ClubName,c.MobilePhone,c.Email,c.Website from clubs c INNER JOIN bridgeeventclubs b where b.EventId=? and b.CreatedBy=? and c.ClubId=b.ClubId and c.CreatedBy=?',[$event_id,$user_id,$user_id]);
            if((count($clubs)>0) && (count($contacts)>0)){
                return view('editcontactevent',['contacts'=>$contacts,'clubs'=>$clubs,'event_id'=>$event_id]);
            }
            elseif((count($clubs)>0) || (count($contacts)>0)){
                return view('editcontactevent',['contacts'=>$contacts,'clubs'=>$clubs,'event_id'=>$event_id]);
            }
            else{
                $request->session()->flash('message.level', 'info');
                $request->session()->flash('message.content', 'Club and Contact Details not added.Please add club and contact details');
                return view('contactevent',['event_id'=>$event_id]);
            }
            
        }
        else{
            $request->session()->flash('message.level', 'info');
            $request->session()->flash('message.content', 'Please login to continue...');
            return view('login');
        }
    }
    public function saveEditEventContact(Request $request){
        $club_id = $request->club_id;
        $club_name = $request->club_name;
        $club_mobile = $request->club_mobile;
        $club_email = $request->club_email;
        $club_website = $request->club_website;
        $contact_id = $request->contact_id;
        $event_contact = $request->event_contact;
        $event_mobile = $request->event_mobile;
        $event_email = $request->event_email;
        $event_id = $request->id;
        $user_id = $request->session()->get('user_id');
        $event_contacts = $request->event_contacts;
            $event_mobiles = $request->event_mobiles;
            $event_emails = $request->event_emails;
            $club_names = $request->club_names;
            $club_mobiles = $request->club_mobiles;
            $club_emails = $request->club_emails;
            $club_websites = $request->club_websites;
            $user_id = $request->session()->get('user_id');
           if($event_contacts!="" && $event_mobiles!="" && $event_emails !="" && $club_names!="" && $club_mobiles!="" && $club_emails!="" && $club_websites!=""){
                for($j=0;$j<count($event_contacts);$j++){
                    $event_contact_details = DB::table('contacts')->insertGetId(array('FirstName'=> $event_contacts[$j],'LastName'=>'NA','Title'=>'NA','Email'=>$event_emails[$j],'Website'=>'NA','Phone'=>$event_mobiles[$j],'DayTimePhone'=>'NA','EveningPhone'=>'NA','PreferredContactMethod'=>'NA','EmergencyContactName'=>'NA','EmergencyContactNumber'=>'NA','AddressId'=>0));
                    $bridge_event_contact = DB::table('bridgeeventcontact')->insertGetId(array('EventId'=>$event_id,'ContactId'=>$event_contact_details,'CreatedBy'=>$user_id,'DeletedBy'=>0));
                }
                for($i=0;$i<count($club_names);$i++){
                    $event_club = DB::table('clubs')->insertGetId(array('ClubName'=>$club_names[$i], 'Description' => 'NA', 'ClubType' => 'NA', 'AddressId'=>0, 'Email' =>  $club_emails[$i],'MobilePhone' => $club_mobiles[$i], 'Website' => $club_websites[$i], 'OpeningHours' => '00:00:00', 'Facebook' => 'NA', 'Twitter' => 'NA', 'GooglePlus' => 'NA', 'Others' => 'NA', 'ClubOwner' =>$user_id , 'IsDeleted' => 'NA', 'CreatedBy' => $user_id, 'UpdatedBy' => $user_id, 'ShortName' => 'NA'));

                    $bridege_event_club = DB::table('bridgeeventclubs')->insertGetId(array('EventId'=>$event_id,'ClubId'=>$event_club,'ScheduleId'=>0,'ApproveStatus'=>'pending','CreatedBy'=>$user_id,'DeletedBy'=>0));
                }
                $request->session()->flash('message.level', 'success');
                $request->session()->flash('message.content', 'Event Contact/Club Details Added Sucessfully...');
                return redirect('edit-contactevent/'.$event_id);
            }
            elseif($club_names!="" && $club_mobiles!="" && $club_emails!="" && $club_websites!=""){
                for($i=0;$i<count($club_names);$i++){
                    $event_club = DB::table('clubs')->insertGetId(array('ClubName'=>$club_names[$i], 'Description' => 'NA', 'ClubType' => 'NA', 'AddressId'=>0, 'Email' =>  $club_emails[$i],'MobilePhone' => $club_mobiles[$i], 'Website' => $club_websites[$i], 'OpeningHours' => '00:00:00', 'Facebook' => 'NA', 'Twitter' => 'NA', 'GooglePlus' => 'NA', 'Others' => 'NA', 'ClubOwner' =>$user_id , 'IsDeleted' => 'NA', 'CreatedBy' => $user_id, 'UpdatedBy' => $user_id, 'ShortName' => 'NA'));

                    $bridege_event_club = DB::table('bridgeeventclubs')->insertGetId(array('EventId'=>$event_id,'ClubId'=>$event_club,'ScheduleId'=>0,'ApproveStatus'=>'pending','CreatedBy'=>$user_id,'DeletedBy'=>0));
                }
                 $request->session()->flash('message.level', 'success');
                $request->session()->flash('message.content', 'Event Contact Details Added Sucessfully...');
                return redirect('edit-contactevent/'.$event_id);
            }
            elseif($event_contacts!="" && $event_mobiles!="" && $event_emails !=""){
                for($j=0;$j<count($event_contacts);$j++){
                    $event_contact_details = DB::table('contacts')->insertGetId(array('FirstName'=> $event_contacts[$j],'LastName'=>'NA','Title'=>'NA','Email'=>$event_emails[$j],'Website'=>'NA','Phone'=>$event_mobiles[$j],'DayTimePhone'=>'NA','EveningPhone'=>'NA','PreferredContactMethod'=>'NA','EmergencyContactName'=>'NA','EmergencyContactNumber'=>'NA','AddressId'=>0));
                    $bridge_event_contact = DB::table('bridgeeventcontact')->insertGetId(array('EventId'=>$event_id,'ContactId'=>$event_contact_details,'CreatedBy'=>$user_id,'DeletedBy'=>0));
                }
                 $request->session()->flash('message.level', 'success');
                $request->session()->flash('message.content', 'Event Club Details Added Sucessfully...');
                return redirect('edit-contactevent/'.$event_id);
            }
        elseif($club_name != "" && $event_contact != ""){
            var_dump($event_mobile);
            var_dump($event_contact);
            for($i=0;$i<count($club_name);$i++){
                echo $club_mobile[$i];
            $update_club = DB::table('clubs')->where('ClubId',$club_id[$i])->update(['ClubName'=>$club_name[$i],'MobilePhone'=>$club_mobile[$i],'Email'=>$club_email[$i],'Website'=>$club_website[$i]]);
            }
            for($j=0;$j<count($event_contact);$j++){
                echo $j;
                
          $update_contact = DB::table('contacts')->where('ContactId',$contact_id[$j])->update(['FirstName'=>$event_contact[$j],'Email'=>$event_email[$j],'Phone'=>$event_mobile[$j]]);
            }
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'Event Club Details Updated Sucessfully...');
            return redirect('edit-contactevent/'.$event_id);
        }
        elseif($event_contact != ""){
            for($j=0;$j<count($event_contact);$j++){
                $event_contact[$i];
           $update_contact = DB::table('contacts')->where('ContactId',$contact_id[$j])->update(['FirstName'=>$event_contact[$j],'Email'=>$event_email[$j],'Phone'=>$event_mobile[$j]]);
           
            }
        $request->session()->flash('message.level', 'success');
        $request->session()->flash('message.content', 'Event Contact Details Updated Sucessfully...');
        return redirect('edit-contactevent/'.$event_id);
        }   
        else{
           for($i=0;$i<count($club_name);$i++){
                echo $club_mobile[$i];
          $update_club = DB::table('clubs')->where('ClubId',$club_id[$i])->update(['ClubName'=>$club_name[$i],'MobilePhone'=>$club_mobile[$i],'Email'=>$club_email[$i],'Website'=>$club_website[$i]]);
            }
        } 
    }
        public function oldSchedule(Request $request) {
        $type = $request->type;
        $id = $request->id;
        if($type == "schedule") {
            $schedulers = DB::select("select ScheduleType,SubType,WeekDay,StartDate,EndDate from schedulerui where EventId=?",[$id]);
            if(count($schedulers) > 0) {
                echo '<h5 class="add_venue"><a href="#"><button class="btn btn-primary" style="background-color:#fff;color:#46A6EA"><i class="fa fa-plus"></i></button></a> Previous Entries</h5>';
                echo '<div class="row" style="border:1px solid #eee">';
                echo "<table class='table table-striped'>";
                echo "<tr><th>ScheduleType</th><th>SubType</th><th>WeekDay</th><th>StartDate</th><th>EndDate</th></tr>";
                foreach($schedulers as $scheduler) {
                    echo "<tr><td>".$scheduler->ScheduleType."</td><td>".$scheduler->SubType."</td><td>".$scheduler->WeekDay."</td><td>".$scheduler->StartDate."</td><td>".$scheduler->EndDate."</td></tr>";
                }
                echo "</table>";
                echo '</div>';
            } else {
                echo "no";
            }
        }
    }