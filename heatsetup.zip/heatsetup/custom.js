//heat
function heats(url){
  var selectedCountry = $(".country option:selected ").val();
  window.location.assign(url+'/'+selectedCountry);
}
function result(url){
  window.location.reload(url);
}
$("#stage-no").ready(function(){
var $regexname=/^([0-9]{3,10})$/;
  $("#stage-no").on('keypress keydown keyup',function(){
    if(!$(this).val().match($regexname)){
      $('#error-msg').show();
    }
    else{
      $('#error-msg').hide();
    }
  });
});
$("#stage-name").ready(function(){
var $regexname=/^([a-zA-Z_ ]{5,30})$/;
  $("#stage-name").on('keypress keydown keyup',function(){
    if(!$(this).val().match($regexname)){
      $('#msg').show();
    }
    else{
      $('#msg').hide();
    }
  });
});
$("#heat-name").ready(function(){
var $regexname=/^([a-zA-Z_ ]{5,30})$/;
  $("#heat-name").on('keypress keydown keyup',function(){
    if(!$(this).val().match($regexname)){
      $('#error').show();
    }
    else{
      $('#error').hide();
    }
  });
});
$("#heat-course").ready(function(){
var $regexname=/^([0-9]{2,10})$/;
  $("#heat-course").on('keypress keydown keyup',function(){
    if(!$(this).val().match($regexname)){
      $('#msg').show();
    }
    else{
      $('#msg').hide();
    }
  });
});
