<?php

Route::get('/heatsetup/{id}','AdminController@setHeat');
Route::post('/heatsetup/{id}','AdminController@heatSetup');
Route::get('/scheduleheat/{event_id}/{subevent_id}/{heat_id}','AdminController@schedule');
Route::post('/scheduleheat/{event_id}/{subevent_id}/{heat_id}','AdminController@scheduleHeat');
Route::get('/oldscheduleheat/{event_id}/{subevent_id}/{heat_id}','AdminController@oldHeatSchedule');
Route::get('/manageparticpants/{event_id}/{subevent_id}/{heat_id}','AdminController@manageParticpants');
Route::post('/manageparticpants/{event_id}/{subevent_id}/{heat_id}','AdminController@saveParticipants');
