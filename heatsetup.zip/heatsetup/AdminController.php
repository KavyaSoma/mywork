<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class SocialController extends Controller
{
     public function setHeat(Request $request){
    if($request->session()->has('user_id')){
      $event_id = $request->id;
      $subevents = DB::select('select SubEventId,SubEventName from subevents where EventId=?',[$event_id]);
      return view('heatsetup',['event_id'=>$event_id,'subevents'=>$subevents]);
    }
    else{
        $request->session()->flash('message.level','danger');
        $request->session()->flash('message.content','Passwords didnot match. Please,Try again..');
        return redirect('login');
    }
  }
    public function heatSetup(Request $request){
    $user_id = $request->session()->get('user_id');
    $event_id = $request->id;
    $subevent = $request->subevents;
    $stage_no = $request->stage_no;
    $stage_name = $request->stage_name;
    $heat_generation = $request->heat_generation;
   
    $event_details = DB::select('select SubEventId,SwimStyle,Relay,MaxParticipants from subevents where SubEventId=?',[$subevent]);
    foreach($event_details as $event_detail){
    $insert_heat = DB::table('eventheats')->insertGetId(array('EventId'=>$event_id,'SubEventId'=>$event_detail->SubEventId,'HeatName'=>'NA','HeatStartDate'=>'0000-00-00','HeatEndDate'=>'0000-00-00','HeatTime'=>'00:00:00','StageNumber'=>$stage_no,'StageName'=>$stage_name,'MaxNoOfParticipants'=>$event_detail->MaxParticipants,'VenueId'=>0,'QualificationTime'=>0,'Relay'=>$event_detail->Relay,'SwimCourse'=>0,'SwimStyle'=>$event_detail->SwimStyle,'ChildHeatId'=>0,'VenueHeatSpecialInstructions'=>'NA','HeatNotes'=>'NA','CreatedBy'=>$user_id,'UpdatedBy'=>$user_id));
      $request->session()->flash('message.level','success');
      $request->session()->flash('message.content','Basic Heat details Added Sucessfully');
      return redirect('scheduleheat/'.$event_id.'/'.$event_detail->SubEventId.'/'.$insert_heat);
   
    }
  }
  public function schedule(Request $request){
    if($request->session()->has('user_id')){
      $event_id = $request->event_id;
      $heat_id = $request->heat_id;
      $subevent_id = $request->subevent_id;
      return view('scheduleheat',['event_id'=>$event_id,'heat_id'=>$heat_id,'subevent_id'=>$subevent_id]);
    }
    else{
        $request->session()->flash('message.level','danger');
        $request->session()->flash('message.content','Passwords didnot match. Please,Try again..');
        return redirect('login');
    }
  }
  public function scheduleHeat(Request $request){
    $event_id = $request->event_id;
    $subevent_id = $request->subevent_id;
    $heat_id = $request->heat_id;
    $heat_name = $request->heat_name;
    $schedule_time = $request->schedule_time;
    $qualification = $request->qualification;
    $qualification_time = $request->qualification_time;
    $schedule_date = $request->schedule_date;
    $course = $request->course;
    $update_heat = DB::update('update eventheats set HeatName=?,HeatTime=?,QualificationTime=?,HeatStartDate=? where HeatId=?',[$heat_name,$schedule_time,$qualification[0],$schedule_date,$heat_id]);
    $request->session()->flash('message.level','success');
    $request->session()->flash('message.content','Heat Scheduled Sucessfully.Add Another Heat or <a href="'.url('manageparticpants/'.$event_id.'/'.$subevent_id.'/'.$heat_id).'"> Click here to Add Participants to Heat...</a>');
    return view('scheduleheat',['event_id'=>$event_id,'heat_id'=>$heat_id,'subevent_id'=>$subevent_id]);
    
  }
  public function manageParticpants(Request $request){
    if($request->session()->has('user_id')){
      $user_id = $request->session()->get('user_id');
      $event_id = $request->event_id;
      $subevent_id = $request->subevent_id;
      $heat_id = $request->heat_id;
      $participants = DB::select('SELECT users.UserId,users.UserName FROM users LEFT JOIN bridgeheatparticipants ON users.UserId = bridgeheatparticipants.ParticipantId and bridgeheatparticipants.EventId=? WHERE users.UserId!=? and bridgeheatparticipants.ParticipantId IS NULL',[$event_id,$user_id]);
      $mainheat = DB::select('select HeatName from eventheats where HeatId=? and EventId=?',[$heat_id,$event_id]);
      $heatname = $mainheat[0]->HeatName;
      $heats = DB::select('select HeatId,HeatName from eventheats where EventId=?',[$event_id]);
      $heat_participants = DB::select('select u.UserName,u.UserId from users u INNER JOIN bridgeheatparticipants b where u.UserId=b.ParticipantId and b.EventId=? and b.HeatId=?',[$event_id,$heat_id]);
      return view('manageparticipants',['participants'=>$participants,'heatname'=>$heatname,'heats'=>$heats,'event_id'=>$event_id,'heat_id'=>$heat_id,'heat_participants'=>$heat_participants,'subevent_id'=>$subevent_id]);
    }
    else{
      $request->session()->flash('message.level','danger');
      $request->session()->flash('message.content','Passwords didnot match. Please,Try again..');
      return redirect('login');
    }
  }

  public function saveParticipants(Request $request){
    $user_id = $request->session()->get('user_id');
    $participant = $request->participants;
    $heats_participants = $request->heats_participants;
    $heats_id = $request->heats_id;
    $heat_id = $request->heat_id;
    $event_id = $request->event_id;
    $subevent_id = $request->subevent_id;
    $participants = DB::select('select u.UserName,u.UserId from users u INNER JOIN bridgeeventparticipants b where u.UserId=b.ParticipantId and b.EventId=?',[$event_id]);
    $heats = DB::select('select HeatId,HeatName from eventheats where EventId=?',[$event_id]);
    $heatname = $heats[0]->HeatName;
    if($participant!=""){
    for($i=0;$i<count($participant);$i++){
    $eventheat = DB::delete('delete from bridgeeventparticipants where EventId=? and ParticipantId=?',[$event_id,$participant[$i]]);
    $set_participants = DB::table('bridgeheatparticipants')->insertGetId(array('HeatId'=>$heat_id,'EventId'=>$event_id,'ParticipantId'=>$participant[$i],'CreatedBy'=>$user_id,'StageNo'=>0,'AssignStatus'=>0));
    }
    $request->session()->flash('message.level','success');
    $request->session()->flash('message.content','Participants Moved to heat');
    return redirect('manageparticpants/'.$event_id.'/'.$subevent_id.'/'.$heat_id);
    }
    elseif($heats_participants!='') {
      for($i=0;$i<count($heats_participants);$i++){
      $removeparticipants = DB::delete('delete from bridgeheatparticipants where EventId=? and ParticipantId=? and HeatId=?',[$event_id,$heats_participants[$i],$heat_id]);
      $set_eventparticipants = DB::table('bridgeeventparticipants')->insertGetId(array('EventId'=>$event_id,'ParticipantId'=>$heats_participants[$i],'GroupId'=>0,'Accepted'=>'yes','CreatedBy'=>$user_id,'DeletedBy'=>0,'ConfirmCode'=>rand(),'ApproverId'=>0,'Status'=>0));
      }
      $request->session()->flash('message.level','success');
      $request->session()->flash('message.content','Participants Removed from heat');
     return redirect('manageparticpants/'.$event_id.'/'.$subevent_id.'/'.$heat_id);
   
    }
    else{
      $request->session()->flash('message.level','success');
      $request->session()->flash('message.content','Changes saved Sucessfully');
    return redirect('manageparticpants/'.$event_id.'/'.$subevent_id.'/'.$heat_id);
    }
  }

  public function oldHeatSchedule(Request $request){
    $event_id = $request->event_id;
    $heat_id = $request->heat_id;
    $subevent_id = $request->subevent_id;
    $schedules = DB::select('select HeatName,HeatStartDate,HeatTime,QualificationTime from eventheats where EventId=? and SubEventId=?',[$event_id,$subevent_id]);
    echo '<h5 class="add_venue"><a href="#"><button class="btn btn-primary" style="background-color:#fff;color:#46A6EA"><i class="fa fa-plus"></i></button></a> Previous Entries</h5>';
                echo '<div class="row" style="border:1px solid #eee">';
                echo "<table class='table table-striped'>";
                echo "<tr><td>Heat Name</td><td>Heat StartDate</td><td>HeatTime</td><td>QualificationTime</td><td>Edit</td><td>Delete</td></tr>";
                foreach($schedules as $schedule) {
                    echo "<tr><td>".$schedule->HeatName."</td><td>".$schedule->HeatStartDate."</td><td>".$schedule->HeatTime."</td><td>".$schedule->QualificationTime."</td><td>Edit</td><td>Delete</td></tr>";
                }
                echo "</table>";
                echo '</div>';
  }
}
