  public function autocomplete(Request $request){
      $contact = $request->contact;
      $tags = DB::select('select ContactId,FirstName,Phone,Email as name from contacts where FirstName like "%'.$contact.'%"');
      if(count($tags)>0) {
        echo json_encode($tags);
      }
  }